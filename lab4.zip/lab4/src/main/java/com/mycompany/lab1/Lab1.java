/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab1;

/**
 *
 * @author iljak
 */
public class Lab1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
